<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<style scoped="scoped">
	#app{
		width: 100vw;
		height: 100vh;
		background-color: #f5f5f5;
	}
</style>
